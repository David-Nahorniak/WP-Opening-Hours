<?php

namespace OpeningHours\Fields;
defined( 'ABSPATH' ) || exit;

/**
 * Class containing field types as constants
 *
 * @author      Jannik Portz
 * @package     OpeningHours\Fields
 */
class FieldTypes {
  const TEXT = 'text';
  const NUMBER = 'number';
  const DATE = 'date';
  const TIME = 'time';
  const EMAIL = 'email';
  const URL = 'url';
  const TEXTAREA = 'textarea';
  const SELECT = 'select';
  const SELECT_MULTI = 'select-multi';
  const CHECKBOX = 'checkbox';
  const HEADING = 'heading';
}
