<?php
/**
 * Minimal admin notice helper shim.
 *
 * The upstream plugin bundles the `iandunn/admin-notice-helper` library through
 * a git submodule (see .gitmodules). When that submodule is not available (for
 * example an uninitialized checkout without network access) this file provides
 * a compatible `add_notice()` API so the plugin can boot and surface notices
 * instead of raising a fatal error during the bootstrap `require_once`.
 *
 * If the real library is present, prefer it by replacing this file.
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

if ( ! function_exists( 'add_notice' ) ) {
  function add_notice( $message = '', $type = 'updated' ) {
    Admin_Notice_Helper::instance()->add( $message, $type );
  }
}

if ( ! class_exists( 'Admin_Notice_Helper' ) ) {
  final class Admin_Notice_Helper {
    protected static $instance;

    /** @var array */
    protected $notices = array();

    public static function instance() {
      if ( null === self::$instance ) {
        self::$instance = new self();
      }

      return self::$instance;
    }

    protected function __construct() {
      add_action( 'admin_notices', array( $this, 'render' ) );
      add_action( 'network_admin_notices', array( $this, 'render' ) );
    }

    public function add( $message = '', $type = 'updated' ) {
      if ( '' === (string) $message ) {
        return;
      }

      $allowed_types = array( 'error', 'updated', 'warning', 'success', 'info' );
      $type = in_array( $type, $allowed_types, true ) ? $type : 'updated';

      $this->notices[] = array(
        'message' => (string) $message,
        'type'    => $type
      );
    }

    public function render() {
      foreach ( $this->notices as $notice ) {
        printf(
          '<div class="notice notice-%1$s"><p>%2$s</p></div>',
          esc_attr( $notice['type'] ),
          wp_kses_post( $notice['message'] )
        );
      }

      $this->notices = array();
    }
  }

  Admin_Notice_Helper::instance();
}